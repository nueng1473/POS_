from Config_Database.config import app, conp
from Error.error import not_found
from flask import jsonify, request
from pymysql import cursors
from re import match
import base64

def convertToBinaryData(filename):
    with open(filename, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return encoded_string

@app.route('/employees', methods=['GET'])
def emp():
    try:
        cursor = conp.cursor(cursors.DictCursor)
        cursor.execute("SELECT d1.emp_ID, d1.gender, d1.emp_name, d1.emp_surname,\
             d1.emp_tel, d1.village, d1.district, d1.profilepic, d4.province, d3.dep_name, d2.pos_name\
              from employee as d1 inner join position as d2 on (d1.pos_ID=d2.pos_ID)\
                inner join department as d3 on(d1.dep_ID=d3.dep_ID) \
                inner join province as d4 on(d1.prov_ID=d4.prov_ID) WHERE d1.status = 2")
        empRows = cursor.fetchall()
        respone = jsonify(empRows)
        respone.status_code = 200
        return respone
    except Exception:
        return not_found()

@app.route('/create_employee', methods=['POST'])
def create_emp():
    try:
        _json = request.json
        _emp_ID = _json['emp_ID']
        _name = _json['emp_name']
        _surname = _json['emp_surname']
        _tel = _json['emp_tel']
        _village = _json['village']
        _district = _json['district']
        _pos_ID = _json['pos_ID']
        _dep_ID = _json['dep_ID']
        _provID = _json['prov_ID']
        _gender = _json['gender']
        _status = 2
        _emp_profilepic = _json['profilepic']
        if _emp_ID and _name and _surname and _tel and _village and _district \
            and _pos_ID and _dep_ID and _provID  and _gender and _emp_profilepic:
            cursor = conp.cursor(cursors.DictCursor)
            cursor.execute('SELECT emp_ID FROM employee WHERE emp_ID = %s', (_emp_ID))
            empid = cursor.fetchone()
            if empid:
                respone = jsonify({'message': 'ມີລະຫັດນີ້ແລ້ວ'})
                respone.status_code = 400
            elif not match(r'[A-Z]+[0-9]+', _emp_ID):
                respone = jsonify({'message': 'ຮູບແບບລະຫັດບໍ່ຖືກຕ້ອງ'})
                respone.status_code = 400
            else:
                sqlQuery = "INSERT INTO employee(emp_ID, emp_name, emp_surname, \
                    gender, emp_tel, village, district, pos_ID, dep_ID, prov_ID, status, profilepic) \
                        VALUES(%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                _emp_profilepic = convertToBinaryData(_emp_profilepic)
                bindData = (_emp_ID, _name, _surname, _gender, _tel, _village,
                            _district, _pos_ID, _dep_ID, _provID, _status, _emp_profilepic)
                cursor.execute(sqlQuery, bindData)
                conp.commit()
                respone = jsonify({'message': 'ເພີ່ມຂໍ້ມູນສຳເລັດ', 'status':'ok'})
                respone.status_code = 200
            return respone
        else:
            respone  =  jsonify({'message': 'ກະລຸນາໃສ່ຂໍ້ມູນໃຫ້ຄົບຖ້ວນ'})
            respone.status_code = 400
            return respone
    except Exception:
        return not_found()

@app.route('/search_employee', methods=['POST'])
def emp_details():
    try:
        _json = request.json
        _emp_ID = _json['emp_ID']
        if _emp_ID:
            cursor = conp.cursor(cursors.DictCursor)
            cursor.execute('SELECT emp_ID FROM employee WHERE emp_ID = %s and status = 2', (_emp_ID))
            empid = cursor.fetchone()
            if not empid:
                respone = jsonify({'message': 'ບໍ່ມີຂໍ້ມູນ'})
                respone.status_code = 400
            else:
                cursor.execute("SELECT d1.emp_ID, d1.gender, d1.emp_name, d1.emp_surname, \
                    d1.village, d1.district, d1.profilepic, d4.province, d3.dep_name, d2.pos_name\
                    from employee as d1 inner join position as d2 on (d1.pos_ID=d2.pos_ID)\
                        inner join department as d3 on(d1.dep_ID=d3.dep_ID) \
                        inner join province as d4 on(d1.prov_ID=d4.prov_ID) WHERE d1.emp_ID = %s and d1.status = 2", (_emp_ID))
                empRow = cursor.fetchone()
                respone = jsonify(empRow)
                respone.status_code = 200
            return respone
    except Exception:
        return not_found()

@app.route('/update_employee', methods=['PUT'])
def update_emp():
    try:
        _json = request.json
        _emp_ID = _json['emp_ID']
        _name = _json['emp_name']
        _surname = _json['emp_surname']
        _tel = _json['emp_tel']
        _village = _json['village']
        _district = _json['district']
        _pos_ID = _json['pos_ID']
        _dep_ID = _json['dep_ID']
        _provID = _json['prov_ID']
        _gender = _json['gender']
        _emp_profilepic = _json['profilepic']
        if _name and _surname and _tel and _village and _district and\
             _pos_ID and _dep_ID and _provID and _gender and _emp_profilepic:
            cursor = conp.cursor(cursors.DictCursor)
            sqlQuery = "UPDATE employee  SET emp_name = %s, emp_surname = %s, gender = %s, \
                emp_tel = %s, village = %s, district = %s, pos_ID = %s, dep_ID = %s, \
                    prov_ID = %s, status = 2, profilepic = %s WHERE (emp_ID = %s)"
            _emp_profilepic = convertToBinaryData(_emp_profilepic)
            bindData = (_name, _surname, _gender, _tel, _village,
                        _district, _pos_ID, _dep_ID, _provID, _emp_profilepic, _emp_ID)
            cursor.execute(sqlQuery, bindData)
            conp.commit()
            respone = jsonify({'message': 'ອັດເດດຂໍ້ມູນສຳເລັດ', 'status':'ok'})
            respone.status_code = 200
        else:
            respone = jsonify({'message': 'ກະລຸນາໃສ່ຂໍ້ມູນໃຫ້ຄົບຖ້ວນ'})
            respone.status_code = 400
        return respone
    except Exception:
        return not_found()

@app.route('/delete_employee', methods=['DELETE'])
def delete_emp():
    try:
        _json = request.json
        _emp_ID = _json['emp_ID']
        cursor = conp.cursor(cursors.DictCursor)
        cursor.execute("UPDATE employee  SET status = 1 WHERE (emp_ID = %s)", (_emp_ID))
        conp.commit()
        respone = jsonify({'message': 'ລົບຂໍ້ມູນສຳເລັດ', 'status': 'ok'})
        respone.status_code = 200
        return respone
    except Exception:
        return not_found()