from Config_Database.config import app, conp
from Error.error import not_found
from flask import jsonify, request
from pymysql import cursors
from re import match

@app.route('/create_department', methods=['POST'])
def create_department():
    try:
        json = request.json
        dep_name = json['dep_name']
        dep_level = json['dep_level']
        if dep_name and dep_level:
            cursor = conp.cursor(cursors.DictCursor)
            sqlQuery = "SELECT dep_name, dep_level FROM department WHERE dep_name = %s"
            bindData = (dep_name)
            cursor.execute(sqlQuery, bindData)
            row = cursor.fetchone()
            if row:
                respone = jsonify({'message': 'ມີຂໍ້ມູນແລ້ວ'})
                respone.status_code = 400
            elif not match(r'[0-9]+', dep_level):
                respone = jsonify({'message':'ໃສໄດ້ແຕ່ໂຕເລກ'})
                respone.status_code = 400
            else:
                cursor.execute('INSERT INTO department(dep_name, dep_level) VALUES(%s, %s)', (dep_name, dep_level))
                conp.commit()
                respone = jsonify({'message':'ເພີ່ມຂໍ້ມູນສຳເລັດ', 'status':'ok'})
                respone.status_code = 200
            return respone
        else:
            respone = jsonify({'message':'ຂໍ້ມູນບໍ່ຄົບຖ້ວນ'})
            respone.status_code = 402
        return respone
    except Exception:
        return not_found()

@app.route('/departments', methods=['GET'])
def department():
    try:
        cursor = conp.cursor(cursors.DictCursor)
        cursor.execute("SELECT dep_name, dep_create_date, dep_level FROM department")
        depRows = cursor.fetchall()
        respone = jsonify(depRows)
        respone.status_code = 200
        return respone
    except Exception:
        return not_found()

@app.route('/search_department', methods=['POST'])
def department_details():
    try:
        json = request.json
        name = json['dep_name']
        if name:
            cursor = conp.cursor(cursors.DictCursor)
            cursor.execute("SELECT dep_name FROM department WHERE dep_name = %s", name)
            depRow = cursor.fetchone()
            if not depRow:
                respone = jsonify({'message': 'ບໍ່ມີຂໍ້ມູນ'})
                respone.status_code = 400
            else:
                cursor.execute("SELECT dep_name, dep_create_date, dep_level FROM department WHERE dep_name = %s", name)
                depRow = cursor.fetchone()
                respone = jsonify(depRow)
                respone.status_code = 200
            return respone
    except Exception:
        return not_found()

@app.route('/update_department', methods=['PUT'])
def update_department():
    try:
        _json = request.json
        _dep_ID = _json['dep_ID']
        _dep_name = _json['dep_name']
        _dep_level = _json['dep_level']
        if _dep_ID and _dep_name and _dep_level:
            cursor = conp.cursor(cursors.DictCursor)
            sqlQuery = "UPDATE department SET dep_name = %s, dep_level = %s WHERE dep_ID = %s"
            bindData = (_dep_name, _dep_level, _dep_ID)
            cursor.execute(sqlQuery, bindData)
            conp.commit()
            respone = jsonify({'message': 'ອັດເດດຂໍ້ມູນສຳເລັດ', 'status':'ok'})
            respone.status_code = 200
        else:
            respone = jsonify({'message': 'ກະລຸນາໃສ່ຂໍ້ມູນໃຫ້ຄົບຖ້ວນ'})
            respone.status_code = 400
        return respone
    except Exception:
        return not_found()

@app.route('/delete_department', methods=['DELETE'])
def delete_department():
    try:
        _json = request.json
        _dep_name = _json['dep_name']
        cursor = conp.cursor(cursors.DictCursor)
        cursor.execute("DELETE FROM department WHERE dep_name =%s", _dep_name)
        conp.commit()
        respone = jsonify({'message': 'ລົບຂໍ້ມູນສຳເລັດ', 'status': 'ok'})
        respone.status_code = 200
        return respone
    except Exception:
        respone = jsonify('ຂໍ້ມູນມີການໃຊ້ງານບໍ່ສາມາດລົບໄດ້')
        respone.status_code = 400
        return respone